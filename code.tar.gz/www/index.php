<?php require("static_top.php"); ?>

<div class="container">

<div class="row">
    <div class="span12">
        <div id="masonry-container">
            <div class="item"><img src="flower.jpg"></div>
            <div class="item"><img src="flower.jpg"></div>
            <div class="item"><img src="flower.jpg"></div>
            <div class="item"><img src="flower.jpg"></div>
            <div class="item"><img src="flower.jpg"></div>
        </div>
    </div>
</div>

</div>

<?php require("static_bottom.php"); ?>